CS 254: Assignment 7

Team Members:
1. Devansh Jain  (190100044)
2. Harshit Varma (190100055)

File Descriptions:

Q1:
    RLE.vhd                         : Contains the Run Length Encoder using behavorial coding
    ASCII_Read_test.vhd             : Modified Testbench for RLE.vhd
    input.txt                       : Input Testcase
    output.txt                      : Output of Testcase
    waveform_1.png & waveform_2.png : Waveforms of the simulation
    report.pdf                      : Description of implementation
    
